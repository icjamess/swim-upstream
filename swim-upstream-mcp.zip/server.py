"""swim-upstream — a fresh remote MCP connector for Claude.

Streamable HTTP, stateless, authless. Serves at /mcp.
Built new; shares nothing with existing connectors.
"""
import os
from mcp.server.fastmcp import FastMCP

mcp = FastMCP(
    "swim-upstream",
    host="0.0.0.0",
    port=int(os.environ.get("PORT", "8000")),
    stateless_http=True,
    json_response=True,
)

MODES = {
    "stem": "sustained headway straight against the gradient",
    "breast": "one continuous push (blocking call)",
    "buffet": "repeated discrete strikes (retry with backoff)",
    "froward": "orientation, not effort: traverse against the edges",
}


@mcp.tool()
def upstream_frame(concept: str, cheap_direction: str, mode: str = "froward") -> dict:
    """Render a concept as motion against its gradient.

    concept: the thing being examined.
    cheap_direction: which way the system naturally flows.
    mode: stem | breast | buffet | froward.
    """
    mode = mode.lower()
    if mode not in MODES:
        return {"error": f"mode must be one of {sorted(MODES)}"}
    return {
        "gradient": f"{concept}: cheap direction is {cheap_direction}",
        "cost": f"moving against '{cheap_direction}' costs attention, latency, and error budget; cost scales with slope",
        "mode": f"{mode} — {MODES[mode]}",
        "termination": "stop when net headway per step falls below epsilon (futility bound)",
        "headway": "measure displacement net of drift; report depth reached, not depth requested",
    }


@mcp.tool()
def headway(slope: float = 0.3, drift: float = 0.1, budget: int = 500,
            effort: float = 1.0, fatigue: float = 0.99, epsilon: float = 1e-3) -> dict:
    """Climb against a gradient until motion ends on its own.

    Each step: net = effort*(1-slope) - drift; effort decays by `fatigue`.
    Halts when net < epsilon or budget (steps) is spent.
    """
    if not 0 <= slope < 1:
        return {"error": "slope must be in [0, 1)"}
    depth, steps, e = 0.0, 0, effort
    reason = "budget exhausted"
    while steps < budget:
        net = e * (1 - slope) - drift
        if net < epsilon:
            reason = "headway below epsilon — edge reached"
            break
        depth += net
        steps += 1
        e *= fatigue
    return {"depth_reached": round(depth, 4), "steps": steps, "stop_reason": reason}


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
