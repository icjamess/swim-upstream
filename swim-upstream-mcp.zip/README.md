# swim-upstream — new remote MCP connector

Fresh build. Adds a new connector alongside existing ones; edits nothing.

## Tools
- `upstream_frame(concept, cheap_direction, mode)` — gradient / cost / mode / termination / headway
- `headway(slope, drift, budget, ...)` — climbs until motion ends; reports depth reached

## Run locally
    pip install -r requirements.txt
    python server.py          # serves http://localhost:8000/mcp

## Deploy (must be public HTTPS — Claude connects from Anthropic's cloud)
Any container host works (Render, Railway, Fly.io, Cloud Run):
    docker build -t swim-upstream . && docker run -p 8000:8000 swim-upstream
The host must set PORT or expose 8000.

## Add to Claude
Customize → Connectors → **+** → Add custom connector
- Name: `swim-upstream` (distinct from existing "upstream")
- URL: `https://<your-host>/mcp`   ← single slash after host, ends in /mcp
- Advanced settings: leave blank (authless)

Then enable it in the chat's tools menu.
